from flask import Flask, render_template, request, redirect, url_for, jsonify
import pyrebase
import UIOperationBook as OpB
import UIOperationUser as OpU
import editBooks as AddB

app = Flask(__name__)

# Firebase configuration
firebaseConfigs = {
"books1":{
  "apiKey": "AIzaSyATRjhPn-8bNDfLn5w4qQ8bEQqmSj0TbiI",
  "authDomain": "books-1-25ca2.firebaseapp.com",
  "databaseURL": "https://books-1-25ca2-default-rtdb.firebaseio.com",
  "projectId": "books-1-25ca2",
  "storageBucket": "books-1-25ca2.appspot.com",
  "messagingSenderId": "363526707564",
  "appId": "1:363526707564:web:6d4ae572d584dac30d3b49",
  "measurementId": "G-2KEW1CRT3P"},
"books2":{
  "apiKey": "AIzaSyCi6GPN4rr6FCIeJuYKP-4p8xbt_NM41Lc",
  "authDomain": "books-2-87c03.firebaseapp.com",
  "databaseURL": "https://books-2-87c03-default-rtdb.firebaseio.com",
  "projectId": "books-2-87c03",
  "storageBucket": "books-2-87c03.appspot.com",
  "messagingSenderId": "387963165991",
  "appId": "1:387963165991:web:9ada686673357815a6dd02",
  "measurementId": "G-YJK7RP3BZ2"
}
}

firebase_apps = {}
def get_firebase_app(project_name):
    if project_name not in firebase_apps:
        firebase_apps[project_name] = pyrebase.initialize_app(firebaseConfigs[project_name])
    return firebase_apps[project_name]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/books/')
def books():
    return render_template('books.html')

@app.route('/users/')
def users():
    return render_template('users.html')

@app.route('/searchBy/', methods=['POST'])
def searchBy():
    id = request.form['searchBy']
    res = OpB.searchByID(id)
    if res:
        return jsonify(res)
    else:
        return jsonify({'Error': 'Book does not exist.'})

@app.route('/search/', methods=['POST'])
def search():
    field = request.form['field'],
    queryV = request.form['queryV']
    print(field[0], queryV)
    if field[0] =="authors":    
        res = OpB.searchBookbyAuthor(queryV)
    else:
        res = OpB.searchBook(field[0], queryV)
    if res:
        return jsonify(res)
    else:
        return jsonify({'Error': 'Book does not exist.'})

@app.route('/insert/', methods=['POST'])
def insert():
    data = {
        'authors': request.form['authors'],
        'title': request.form['title'],
        'isbn13': request.form['isbn13'],
        'language': request.form['language'],
        'subjects': request.form['subjects'],
        'publisher': request.form['publisher'],
        'date_published': request.form['date'],
        'availableNums': request.form['availableNums']
    }
    if data['date_published']:
        data['date_published'] = int(data['date_published'])
    if data['availableNums']:
        data['availableNums'] = int(data['availableNums'])
    data["authors"] = list(data["authors"].split(","))
    res = OpB.insertBook(data)
    if res == 200:     
        return "Inserte data successfully!"
    else:
        return f"Error: Status Code {res}."
        

@app.route('/update/', methods=['POST'])
def update():
    data = {
        'id': request.form['bookid'],
        'authors': request.form['authors'],
        'title': request.form['title'],
        'language': request.form['language'],
        'subjects': request.form['subjects'],
        'publisher': request.form['publisher'],
        'date_published': request.form['date'],
        'availableNums': request.form['availableNums']
    }
    if data['date_published']:
        data['date_published'] = int(data['date_published'])
    if data['availableNums']:
        data['availableNums'] = int(data['availableNums'])
    res = OpB.updateBook(data)
    if res == 200:     
        return f"Update data successfully!"
    elif res == -100:
        return f"Data doesn't exist. Please enter correct book ID."
    else:
        return f"Error: Status Code {res}."

@app.route('/delete/', methods=['POST'])
def delete():
    id = request.form['bookid']
    field = request.form['field']
    queryV = request.form['queryV']
    print(field[0], queryV)
    if id:
        res = OpB.deleteOneBook(id)
    else:
        res = OpB.deleteBooks(field, queryV)
    if res == 200:     
        return f"Delete data successfully!"
    if res == 0:     
        return f"Data does not exist."
    else:
        return f"Error: Status Code {res}."

@app.route('/clear/', methods=['POST'])
def clear():
    res = OpB.clearAll()
    if res == 200:     
        return "Clear data successfully!"
    else:
        return f"Error: Status Code {res}."

@app.route('/usearchBy/', methods=['POST'])
def usearchBy():
    field = request.form['field']
    query = request.form['usearchBy']
    if field == "id":
        res = OpU.searchByID(query)
    else:
        res = OpU.search(query)
    if res:
        return jsonify(res)
    else:
        return jsonify({'Error': 'User does not exist.'})

@app.route('/uinsert/', methods=['POST'])
def uinsert():
    unavailable_li = []
    id = request.form['id']
    books = {"NoBorrowedBook": True}
    date = OpU.editdate()
    if request.form['book1']!= "":
        book = request.form['book1']
        num_status= AddB.subNUM(book)
        if num_status == -18:
            unavailable_li.append(book)
        else:
            books[book] = date
            books["NoBorrowedBook"] = False
    if request.form['book2'] != "":
        book = request.form['book2']
        num_status= AddB.subNUM(book)
        if num_status == -18:
            unavailable_li.append(book)
        else:
            books[book] = date
            books["NoBorrowedBook"] = False
    if request.form['book3']!= "":
        book = request.form['book3']
        num_status= AddB.subNUM(book)
        if num_status == -18:
            unavailable_li.append(book)
        else:
            books[book] = date
            books["NoBorrowedBook"] = False
    if request.form['book4']!= "":
        book = request.form['book4']
        num_status= AddB.subNUM(book)
        if num_status == -18:
            unavailable_li.append(book)
        else:
            books[book] = date
            books["NoBorrowedBook"] = False
    if request.form['book5']!= "":
        book = request.form['book5']
        num_status= AddB.subNUM(book)
        if num_status == -18:
            unavailable_li.append(book)
        else:
            books[book] = date
            books["NoBorrowedBook"] = False
    password = request.form['password']
    user_name = request.form['user_name']
    info = {"books": books, "password": password, "user_name":user_name}
    res = OpU.insertUser(id, info)
    if res == 200:    
        if len(unavailable_li) > 0:
            return f" Warning: Books {unavailable_li} are not available. Insert other data successfully!"
        return "Insert data successfully!"
    elif res == -1:     
        return "ID already exists."
    elif res == -2:     
        return "Username already exists."
    else:
        return f"Error: Status Code {res}."

@app.route('/uupdate/', methods=['POST'])
def uupdate():
    Not_available = []
    j = [True, True, True, True, True]
    id = request.form['id']
    opeartion = request.form['bookoperation']
    books = {"NoBorrowedBook": True}
    books_li = [request.form['book1'], request.form['book2'], request.form['book3'], request.form['book4'], request.form['book5']]
    if opeartion == "add" or opeartion == "rewrite":
        Not_available, j = OpU.subALLOne(books_li)
    if opeartion == "delete":
        OpU.addAllOne(books_li)
    if opeartion == "clear" or opeartion == "rewrite":
        books_li = OpU.queryBookByUser(id)
        OpU.addAllOne(books_li)

    if request.form['book1'] and j[0]:
        book = request.form['book1']
        books[book] = OpU.getdate(request.form['date1'])
        books["NoBorrowedBook"] = False
    if request.form['book2'] and j[1]:
        book = request.form['book2']
        books[book] = OpU.getdate(request.form['date2'])
        books["NoBorrowedBook"] = False
    if request.form['book3'] and j[2]:
        book = request.form['book3']
        books[book] = OpU.getdate(request.form['date3'])
        books["NoBorrowedBook"] = False
    if request.form['book4'] and j[3]:
        book = request.form['book4']
        books[book] = OpU.getdate(request.form['date4'])
        books["NoBorrowedBook"] = False
    if request.form['book5'] and j[4]:
        book = request.form['book5']
        books[book] = OpU.getdate(request.form['date5'])
        books["NoBorrowedBook"] = False
    if opeartion == "clear":
        books = {"NoBorrowedBook": True}
    res = OpU.updateUser(id, opeartion, books)
    if res == 200:
        if len(Not_available) > 0:
            return f"Warning: Books {Not_available} are not available. Update other data successfully!"
        return "Update data successfully!"
    elif res == -1:     
        return "User does not exists."
    else:
        return f"Error: Status Code {res}."

@app.route('/udelete/', methods=['POST'])
def udelete():
    field = request.form['field']
    query = request.form['queryV']
    res = OpU.deleteUser(field, query)
    if res == 200:     
        return "Delete data successfully!"
    else:
        return f"Error: Status Code {res}."


@app.route('/uclear/', methods=['POST'])
def uclear():
    res = OpU.clearAll()
    if res == 200:     
        return "Clear data successfully!"
    else:
        return f"Error: Status Code {res}."

if __name__ == '__main__':
    app.run(debug=True)

