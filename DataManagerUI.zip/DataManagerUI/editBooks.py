import HashingURL as HU
import requests
import json
import random
import time
import re

#"History", "Science", "Art", "Horror", "Health", "Travel", "Crime", "Cookbook", "Business", "Drama", "Education", "Philosophy", "Photography", "Political", "Music", "Religion"
subjects = ["Horror", "Health", "Travel", "Crime", "Cookbook", "Business", "Drama", "Education", "Philosophy", "Photography", "Political", "Music", "Religion"]

def addAuthorNames(isbn, name, title):
    h_value = HU.hash_book(isbn)
    update_info = {"title": title}
    update_json = json.dumps(update_info)
    url = f"{HU.get_book_path(h_value)}/author/{name}/{isbn}.json"
    response = requests.put(url, data = update_json)
    return response.status_code

def updateAuthorNames(isbn, name, title):
    h_value = HU.hash_book(isbn)
    names = name.split()
    update_info = {"title": title}
    update_json = json.dumps(update_info)
    for name in names:
        pushName = re.sub(r'^[^a-zA-Z]+|[^a-zA-Z]+$', '', name)
        if pushName and len(pushName)>1:
            url = f"{HU.get_book_path(h_value)}/authorKeyWord/{pushName}/{isbn}.json"
            response = requests.put(url, data = update_json)
    return response.status_code

def deleteAuthorNames(isbn, name):
    h_value = HU.hash_book(isbn)
    url = f"{HU.get_book_path(h_value)}/author/{name}/{isbn}.json"
    response = requests.delete(url)
    return response.status_code

def removeAuthorNames(isbn, name):
    h_value = HU.hash_book(isbn)
    names = name.split()
    for name in names:
        pushName = re.sub(r'^[^a-zA-Z]+|[^a-zA-Z]+$', '', name)
        if pushName and len(pushName)>1:
            url = f"{HU.get_book_path(h_value)}/authorKeyWord/{pushName}/{isbn}.json"
            response = requests.delete(url)
    return response.status_code

def queryAuthorNames(isbn):
    h_value = HU.hash_book(isbn)
    url = f"{HU.get_book_path(h_value)}/books/{isbn}/authors.json"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return {}
    
def renewAuthorNames(isbn, name, title):
    h_value = HU.hash_book(isbn)
    names = name.split()
    update_info = {"title": title}
    update_json = json.dumps(update_info)
    for name in names:
        pushName = re.sub(r'^[^a-zA-Z]+|[^a-zA-Z]+$', '', name)
        if pushName and len(pushName)>1:
            url = f"{HU.get_book_path(h_value)}/authorKeyWord/{pushName}/{isbn}.json"
            response = requests.patch(url, data=update_json)
    return response.status_code

def renewAuthor(isbn, name, title):
    h_value = HU.hash_book(isbn)
    update_info = {"title": title}
    update_json = json.dumps(update_info)
    url = f"{HU.get_book_path(h_value)}/authorKeyWord/{name}/{isbn}.json"
    response = requests.patch(url, data=update_json)
    return response.status_code

def add_book(isbn, book_json):
    h_value = HU.hash_book(isbn)
    url = f"{HU.get_book_path(h_value)}/books/{isbn}.json"
    response = requests.put(url, data = book_json)
    return response.status_code

def delete_book(isbn):
    h_value = HU.hash_book(isbn)
    url = f"{HU.get_book_path(h_value)}/books/{isbn}.json"
    response = requests.delete(url)
    return response.status_code

def update_book(id, item):
    isbn = int(id)
    h_value = HU.hash_book(isbn)
    url = f"{HU.get_book_path(h_value)}/books/{id}.json"
    response = requests.get(url) 
    if response.json() is None or response.status_code != 200:
        return -100
    title = response.json()["title"]
    update_info = {}
    for key in item.keys():
        if item[key] != "" and key != "id":
            update_info[key] = item[key]
    if "title" in update_info.keys():
        title = update_info["title"]
        if "authors" not in update_info.keys():
            name_li = queryAuthorNames(isbn)
            if name_li:
                li =name_li.keys()
                for name in li:
                    # update title in keyword
                    renewAuthorNames(isbn, name, title)
                    renewAuthor(isbn, name, title)
    #not update successfully            
    if "authors" in update_info.keys():
        name_li = queryAuthorNames(isbn)
        if name_li:
            li =name_li.keys()
            for name in li:
                removeAuthorNames(isbn, name)
                deleteAuthorNames(isbn, name)
        requests.delete(f"{url}/authors.json")

        update_info["authors"] = list(update_info["authors"].split(","))
        li = update_info["authors"]
        hash_map = {}
        for name in li:
            hash_map[name.strip()] = True
        update_info["authors"] = hash_map
        li = list(hash_map.keys())
        #print(li)
        for name in li:
            #print(name)
            updateAuthorNames(isbn, name, title)
            addAuthorNames(isbn, name, title)
        requests.put(f"{url}/authors.json", data = json.dumps(hash_map))

    if "availableNums" in update_info.keys():
        update_info["availableNums"] = int(update_info["availableNums"])
    if "date_published" in update_info.keys():
        update_info["date_published"] = int(update_info["date_published"])
    update_json = json.dumps(update_info)
    response_ = requests.patch(url, data=update_json)
    return response_.status_code

def addNUM(isbn):
    print("ADddddddddddddddd!")
    isbn = int(isbn)
    item = {}
    h_value = HU.hash_book(isbn)
    url = f"{HU.get_book_path(h_value)}books/{isbn}/availableNums.json"
    response = requests.get(url)
    num = response.json()
    print(num)
    item["availableNums"] = num+1
    res = update_book(isbn, item)
    return res

def subNUM(id):
    print("Subbbbbb!")
    isbn = int(id)
    item = {}
    h_value = HU.hash_book(isbn)
    url = f"{HU.get_book_path(h_value)}books/{id}/availableNums.json"
    response = requests.get(url)
    num = response.json()
    print(num)
    if num >=1: 
        item["availableNums"] = num-1
        res = update_book(id, item)
        return res
    else:
        return -18

if __name__ == "__main__":
    for subject in subjects:
        print(subject)
        with open(f'books_{subject}.json', 'r') as json_file:
            data = json.load(json_file)
            index = 0
            for item in data[:1000]:
                print(index)
                index+=1
                item["subjects"] = subject
                item["availableNums"] = random.randint(5, 10)
                isbn = int(item["isbn13"])
                title = item["title"]
                item["isbn13"] = isbn
                if item["date_published"]:
                    try: 
                        item["date_published"] = int(str(item["date_published"])[0:4])
                    except:
                        item["date_published"] = item["date_published"]

                li = item["authors"]
                hash_map = {}
                for name in li:
                    hash_map[name] = True
                item["authors"] = hash_map
                book_json = json.dumps(item)
                for name in item["authors"]:
                    updateAuthorNames(isbn,name, title)
                add_book(isbn,book_json)
                if index % 100 == 0:
                    time.sleep(120)
                if index % 500 == 0:
                    time.sleep(300)
            time.sleep(300)
                
