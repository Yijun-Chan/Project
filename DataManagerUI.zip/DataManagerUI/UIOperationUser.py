import json
import requests
import sys
import HashingURL as Hurl
import editBooks as AddB
import UIOperationBook as OpB
from datetime import datetime, timedelta, date

def editdate():
    date_info = {}
    start_date = date.today()
    input_date = start_date
    start_date = start_date.strftime("%Y-%m-%d")
    output_date = input_date + timedelta(days=14)
    due_date = output_date.strftime("%Y-%m-%d")
    date_info["start_date"] = start_date
    date_info["due_date"] = due_date
    return date_info

def editdate1(start_date):
    date_info = {}
    input_date = datetime.strptime(start_date, "%Y-%m-%d").date()
    output_date = input_date + timedelta(days=14)
    due_date = output_date.strftime("%Y-%m-%d")
    date_info["start_date"] = start_date
    date_info["due_date"] = due_date
    return date_info

def getdate(d):
    if d == "":
        return editdate()
    else:
        return editdate1(d)

def addAllOne(li):
    if li == []:
        return
    for book in li:
        if book == "":
            continue
        res = AddB.addNUM(book)
    return

def subALLOne(li):
    if li == []:
        return
    not_availble = []
    TF_L = []
    for book in li:
        if book == "":
            continue
        res = AddB.subNUM(book)
        if res == 18:
            not_availble.append(book)
            TF_L.append(False)
        else:
            TF_L.append(True)
    return not_availble, TF_L

def queryBookByUser(id):
    li = []
    isbn = int(id)
    h_value = Hurl.hash_user(isbn)
    url = f"{Hurl.get_user_path(h_value)}/{id}/books.json"
    response = requests.get(url)
    data = response.json()
    print(url)
    if response.status_code == 200 and data is not None:
        li = list(data.keys())
        li.remove('NoBorrowedBook')
    return li


def searchByID(id):
    h_value = Hurl.hash_user(int(id))
    url = f"{Hurl.get_user_path(h_value)}/{id}.json"
    response = requests.get(url)
    data = response.json()
    if response.status_code == 200 and data is not None:
        data.pop("password", None)
        return {id:data}
    else:
        return {}
    
def search(query):
    res = {}
    for i in range(2):
        url = Hurl.get_user_path(i)
        query_url = f"{url}.json?orderBy=\"user_name\"&equalTo=\"{query}\""
        response = requests.get(query_url)
        users = response.json()
        for id in users:
            users[id].pop("password", None)
        res.update(users)
    return res
        
def insertUser(id, info):
    h_value = Hurl.hash_user(int(id))
    url = f"{Hurl.get_user_path(h_value)}/{id}.json"
    response = requests.get(url)
    if response.status_code == 200 and response.json() is not None:
        return -1
    exist_name = search(info["user_name"])
    if exist_name != {}:
        return -2
    user_json = json.dumps(info)
    response = requests.put(url, data = user_json)
    return response.status_code

def updateUser(id, opeartion, books):
    h_value = Hurl.hash_user(int(id))
    url = f"{Hurl.get_user_path(h_value)}/{id}.json"
    response = requests.get(url)
    if response.status_code == 200 and response.json() is None:
        return -1
    if opeartion == "add":
        response = requests.get(f"{Hurl.get_user_path(h_value)}/{id}/books.json")
        li = response.json()
        for key in list(books.keys()):
            if key != "NoBorrowedBook":
                li[key] = books[key]
        if len(list(li.keys())) > 1:
            li["NoBorrowedBook"] = False
        books = li
    if opeartion == "delete":
        response = requests.get(f"{Hurl.get_user_path(h_value)}/{id}/books.json")
        li = response.json()
        for key in list(books.keys()):
            li.pop(key, None)
        li["NoBorrowedBook"] = True
        if len(list(li.keys())) > 1:
            li["NoBorrowedBook"] = False
        books = li
    
    response = requests.delete(f"{Hurl.get_user_path(h_value)}/{id}/books.json")
    book_json = json.dumps(books)
    requests.put(f"{Hurl.get_user_path(h_value)}/{id}/books.json", data = book_json)
    return response.status_code

def deleteUser(field, query):
    if field == "id":
        print("bokkkkkkkkkkkkkkkkkkk")
        h_value = Hurl.hash_user(int(query))
        url = f"{Hurl.get_user_path(h_value)}/{query}.json"
        oldBookList = queryBookByUser(query)
        print("Book_list", oldBookList)
        for book_id in oldBookList:
            print("Book_ID", book_id)
            AddB.addNUM(book_id)
        response = requests.delete(url)
        return response.status_code
    else:
        for i in range(2):
            url = Hurl.get_user_path(i)
            query_url = f"{url}.json?orderBy=\"user_name\"&equalTo=\"{query}\""
            response = requests.get(query_url)
            users = response.json()
            if users:
                for user_id in users:
                    oldBookList = queryBookByUser(user_id)
                    for book_id in oldBookList:
                        print("Book_ID", book_id)
                        AddB.addNUM(book_id)
                    delete_url = f"{url}/{user_id}.json"
                    delete_response = requests.delete(delete_url)
                    return delete_response.status_code
            else:
                return response.status_code

def clearAll():
    res = []
    for i in range(2):
        url = Hurl.get_user_path(i)
        root_url = f"{url}.json"
        response = requests.delete(root_url)
        if response.status_code != 200:
            res.append(response.status_code)
    if len(res) == 0:
        return 200
    else:
        return res[0]
    
