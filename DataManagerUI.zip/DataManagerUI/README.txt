Python 3.8.3
install Flask Pyrebase
Run UI.py, browse http://127.0.0.1:5000 to use the UI. 
Case sensitive for all input string.
ISBN does not start with 0, it is a 13-digit number start with 978.
Input book's authours can have multiple names, separated by a comma.
Initial subjects includes "History", "Science", "Art", "Horror", "Health", "Travel", "Crime", "Cookbook", "Business", "Drama", "Education", "Philosophy", "Photography", "Political", "Music", "Religion".
Any input id of user database should be a 6-digit number except 000000/000001, which can start with 0.
When inserting user data, id and username should be unique.