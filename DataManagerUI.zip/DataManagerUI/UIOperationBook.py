import json
import requests
import sys
import HashingURL as Hurl
import editBooks as AddB
import re

def searchByID(id):
    isbn = int(id)
    h_value = Hurl.hash_book(isbn)
    url = f"{Hurl.get_book_path(h_value)}/books/{isbn}.json"
    response = requests.get(url)
    if response.status_code == 200:
        return {isbn:response.json()}
    else:
        return {}

def searchBook(field, queryV):
    res = {}
    for i in range(5):
        url = f"{Hurl.get_book_path(i)}/books"
        if field in ["date_published", "availableNums"]:
            query_url = f"{url}.json?orderBy=\"{field}\"&equalTo={queryV}"
        else:
            query_url = f"{url}.json?orderBy=\"{field}\"&equalTo=\"{queryV}\""
        response = requests.get(query_url)
        books = response.json()
        if isinstance(books, dict):
            res.update(books)
            num = len(res)
            if num >= 300: return res
    return res

def searchBookbyAuthor(name):
    res = {}
    tmp_res = {}
    for i in range(5):
        tmp_id = {}
        query_url = f"{Hurl.get_book_path(i)}author/{name}.json"
        response = requests.get(query_url)
        books = response.json()
        #print(books)
        if books is None:
            continue
        else:
            if tmp_id == {}:
                tmp_id = books
            else:
                tmp_id = {k: books[k] for k in books if k in tmp_id}
        tmp_res.update(tmp_id)
    if tmp_res != {}:
        for key in tmp_res.keys():
            book = searchByID(key)
            res.update(book)
    return res

def insertBook(item):
    isbn = int(item["isbn13"])
    item["isbn13"] = isbn
    title = item["title"]
    li = item["authors"]
    hash_map = {}
    for name in li:
        hash_map[name] = True
        AddB.addAuthorNames(isbn, name, title)
    item["authors"] = hash_map
    book_json = json.dumps(item)
    for name in li:
        AddB.updateAuthorNames(isbn, name, title)
    status_code = AddB.add_book(isbn,book_json)
    return status_code

def updateBook(item):
    # Check whether input correct ID
    if item["id"]:
        isbn = int(item["id"])
    else:
        return -100
    status_code = AddB.update_book(isbn, item)
    return status_code

def deleteOneBook(isbn):
    isbn = int(isbn)
    name_li = AddB.queryAuthorNames(isbn)
    if name_li:
        li =name_li.keys()
        for name in li:
            AddB.deleteAuthorNames(isbn, name)
            AddB.removeAuthorNames(isbn, name)
    status_code = AddB.delete_book(isbn)
    return status_code

def deleteBooks(field, queryV):
    status_code = 0
    if field == "authors":
        res = searchBookbyAuthor(queryV)
    else:
        res = searchBook(field, queryV)
    if res is not None:
        for key in res.keys():
            status_code = deleteOneBook(int(key))
    return status_code

def clearAll():
    res = []
    for i in range(5):
        url = Hurl.get_book_path(i)
        root_url = f"{url}.json"
        response = requests.delete(root_url)
        if response.status_code != 200:
            res.append(response.status_code)
    if len(res) == 0:
        return 200
    else:
        return res[0]